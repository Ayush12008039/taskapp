package com.kazungudev.taskapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
