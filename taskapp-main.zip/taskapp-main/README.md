# taskapp

A  Flutter  app for managing your personal to-do-list, using firebase..

## Screenshots

![Screenshot_1692764746](https://github.com/KazunguDev/taskapp/assets/88532016/8267b9b3-388f-4ad3-8807-a506d8ccab76)


![Screenshot_1692765668](https://github.com/KazunguDev/taskapp/assets/88532016/f9a9b202-3ce1-4e82-b6c6-43e96230fdaf)


![Screenshot_1692765704](https://github.com/KazunguDev/taskapp/assets/88532016/f9401954-caab-4b95-9e60-64e1ab32b73e)

![Screenshot_1692765729](https://github.com/KazunguDev/taskapp/assets/88532016/2314673c-b9c0-4d92-a816-8aefe49288f3)



