class DateModel{
  String fullDate;
  String dayName;
  String monthName;
  String date;
  String time;
  DateModel({
    required this.fullDate,
    required this.dayName, required this.date, required this.monthName, required this.time});


}